import { logout } from "../services/userService";

const Logout = () => logout();

export default Logout;
