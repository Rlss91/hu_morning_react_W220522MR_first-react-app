import NavBar from "./NavBar/NavBar";

const Header = ({ user }) => <NavBar user={user} />;

export default Header;
